#!/bin/bash

export LC_ALL=en_US

SETLOCALE="$( locale | grep LANG | awk -F = '{print $2}' | cut -c 1-5 )"

for LOCALE in ca_ES de_DE en_US es_ES fr_FR hu_HU it_IT pl_PL pt_BR sk_SK tr_TR; do
   if [ "$SETLOCALE" = "$LOCALE" ] ; then
      export LANG="$LOCALE"
      export LC_ALL="$LOCALE"
   fi
done

for LOCALE in ja_JP ru_RU zh_CN zh_TW; do
   if [ "$SETLOCALE" = "$LOCALE" ] ; then
      export LANG="$LOCALE.UTF-8"
      export LC_ALL="$LOCALE.UTF-8"
   fi
done

# On PartedMagic /etc/debian_version belongs to the live session, so the
# wrapper overwrites it and deletes it at the end.  On an installed Debian
# system that file is the system's own, so save and restore it instead.
DEBIAN_VERSION_SAVED=
if [ -e /etc/debian_version ]; then
   DEBIAN_VERSION_SAVED="$(mktemp /tmp/debian_version.XXXXXX)" &&
      cp -a /etc/debian_version "$DEBIAN_VERSION_SAVED"
fi

echo "sid" > /etc/debian_version

/usr/sbin/clonezilla -s
/usr/sbin/ocs-live-final-action

#clonezilla leaves these mounted when the program is finished. These need to be umounted.
umount /home/partimag &> /dev/null
umount /tmp/local-dev &> /dev/null

if [ -n "$DEBIAN_VERSION_SAVED" ]; then
   cp -a "$DEBIAN_VERSION_SAVED" /etc/debian_version
   rm -f "$DEBIAN_VERSION_SAVED"
else
   rm -f /etc/debian_version &> /dev/null
fi
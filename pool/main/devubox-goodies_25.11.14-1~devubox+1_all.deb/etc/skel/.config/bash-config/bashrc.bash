
source /usr/bin/fancy-prompts.bash
prompt-curl  --lines="0" --right="0" --date="" --time="" --prompt="" --title=""
export HISTSIZE=-1

# Generated file - DO NOT EDIT.  Edit config.py.in instead.

prefix="/usr"
datadir="share"
localedir="/usr/share/locale"
pkgdatadir="/usr/share/warpinator"
libdir="lib/x86_64-linux-gnu"
libexecdir="/usr/libexec/warpinator"
include_firewall_mod=True
bundle_zeroconf=True
bundle_grpc=True
PACKAGE="warpinator"
VERSION="2.0.4"
GETTEXT_PACKAGE="warpinator"
FLATPAK_BUILD=False
RPC_API_VERSION="2"



###################### This is not a constant #########################
# sandbox_mode is set in warpinator.py __main__ at launch.
sandbox_mode = "legacy"

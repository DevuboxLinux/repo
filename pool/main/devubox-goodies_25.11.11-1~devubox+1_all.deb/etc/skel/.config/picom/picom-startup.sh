#!/bin/sh

GL_RENDERER=$(glxinfo -B 2>/dev/null | grep "OpenGL renderer string" | cut -d: -f2- | sed 's/^ *//')
GPU_VENDOR=$(lspci -nn | grep -E "VGA|3D|Display" | cut -d: -f3- | sed 's/^ *//')
INFO="$GL_RENDERER $GPU_VENDOR"

launch_picom() {
    if [ "$1" = "xrender" ]; then
        echo "→ Using xrender backend (no vsync)"
        sleep 3s
        killall -u $(id -nu) picom 2>/dev/null
        picom -b --backend=xrender --no-vsync --config "$HOME/.config/picom.conf" &
    else
        echo "→ Using glx backend (vsync enabled)"
        sleep 3s
        killall -u $(id -nu) picom 2>/dev/null
        picom -b --config "$HOME/.config/picom.conf" &
    fi
}

# 1. No OpenGL renderer → likely no driver or X11 issue
if [ -z "$GL_RENDERER" ]; then
    echo "No OpenGL renderer detected, falling back to xrender."
    launch_picom xrender
    exit
fi

# 2. Software renderer
if echo "$INFO" | grep -qiE "llvmpipe|softpipe|Software Rasterizer"; then
    echo "Software rendering detected ($GL_RENDERER)."
    launch_picom xrender
    exit
fi

# 3. Virtual GPU detection
if echo "$INFO" | grep -qiE "VirtualBox|VMware|VMSVGA|QXL|Virtio|Red Hat|Bochs|KVM"; then
    echo "Virtual machine GPU detected ($GPU_VENDOR / $GL_RENDERER)."
    launch_picom xrender
    exit
fi

# 4. Weak or legacy GPUs (Intel HD2000/HD3000 etc.)
if echo "$INFO" | grep -qiE \
"HD Graphics 2000|HD Graphics 3000|GMA|PowerVR|VIA|SiS|Matrox|ASPEED|Microsoft Basic|Generic VGA|Bochs|Trident|S3|Cirrus|RIVA|Mach64|Savage|Voodoo|Radeon (X|HD [1-4]|2|3|4|RS|RV)|GeForce (FX|6|7|8|9|Go|9400|9300)|NV1|NV2|NV3|NV4|NV5"; then
    echo "Weak or legacy GPU detected ($GL_RENDERER / $GPU_VENDOR)."
    launch_picom xrender
    exit
fi

# 5. Default: real GPU, GLX supported
echo "Detected GPU: $GPU_VENDOR"
echo "Renderer: $GL_RENDERER"
launch_picom glx

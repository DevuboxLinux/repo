#!/bin/sh

sleep 3s
killall -u $(id -nu) conky 2>/dev/null
cd "$HOME/.conky/Devubox"
conky -c "$HOME/.conky/Devubox/conkyrc" &
exit 0

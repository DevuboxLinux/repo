SimpleScreenRecorder contributors
=================================

Programming
-----------

- Maarten Baert
- Boran Car (GLInject hotkey workaround)
- Dubslow (profiles)
- Dmitry Kostenko ('simpleui' patches)

Graphics
--------

- David Revoy (icon)
- Mrallowski (original camera lens from openclipart.org)
- Maarten Baert (header)

Build system
------------

- Maarten Baert
- Michał Walenciak (switch to cmake)

Translations
------------

- Arabic: Abdulla
- Bulgarian: Svetoslav Sashkov
- Czech: Radek Steiger
- German: Manuel Schömburg, AlexMI
- Greek: Nick Thom
- Spanish: Dani Rodríguez
- French: Mario Roger, Olivier Humbert
- Hebrew: GreenLunar
- Hungarian: ViBE, Balázs Úr
- Indonesian: Arif Budiman
- Italian: Bersil
- Japanese: Tou Omiya, Utuhiro78
- Lithuanian: welaq
- Dutch: Maarten Baert
- Polish: Szamanx0, Vetyt Yhonay, Michał Walenciak
- Brazilian Portuguese: Paulo Milliet Roque, Rafael Ferreira
- Russian: Dima Koshel, Vladi105, Olesya Gerasimenko
- Serbian: Zvicko
- Slovakian: Jose Riha
- Swedish: Åke Engelbrektson
- Ukrainian: Rom Gyrfalco
- Simplified Chinese: Weitian Leung
- Traditional Chinese: Estea Chen, Hsiu-Ming Chang
